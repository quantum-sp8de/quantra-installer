#!/usr/bin/env python3

import os
import sys
import logging
from logging.handlers import RotatingFileHandler
import argparse
import getpass

from ..config import config_read, config_save, CONFIG_OPTS
from ..main import quantra_main, QUANTRA_HOMEDIR, QCICADA_DEVICE

log = logging.getLogger('quantra')


def do_input_initial_cfg(missing):
    cfg = {}
    for opt, desc in missing:
        cfg[opt] = input("%s(%s): " % (opt, desc))

    return cfg

def setup_logger(debug_flag, logdir, device):
    log.setLevel(logging.DEBUG)

    level = logging.INFO
    fmt = logging.Formatter('%(asctime)s:%(levelname)s: %(message)s')
    fmt_debug = logging.Formatter('%(asctime)s:%(levelname)s:%(filename)s:%(lineno)d: %(message)s')
    if debug_flag:
        level = logging.DEBUG
        fmt = fmt_debug

    sh = logging.StreamHandler()
    sh.setLevel(level)
    sh.setFormatter(fmt)
    log.addHandler(sh)

    logname_full = os.path.join(logdir, os.path.basename(device) + '_quantra.log')

    fh = RotatingFileHandler(logname_full, mode='a',
                             maxBytes=500*1024*1024,
                             backupCount=2, encoding=None, delay=0)
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt_debug)
    log.addHandler(fh)

def tui_main():
    """ Command line interface main emtry point """

    parser = argparse.ArgumentParser(prog='quantra')
    parser.add_argument('-c','--config', help='configuration file to be used for the program', default=os.path.join(QUANTRA_HOMEDIR,"quantra.yaml"))
    parser.add_argument('-v','--verbose', help='print additional debug information', action='store_true', default=False)
    parser.add_argument('-l','--logdir', help='directory with log file', default=QUANTRA_HOMEDIR)
    parser.add_argument('-d','--device', help='path to QCicada device', default=QCICADA_DEVICE)
    parser.add_argument('-r','--random', help='random generation backend', choices=['qcicada',], default='qcicada')

    if not os.path.exists(QUANTRA_HOMEDIR):
        os.mkdir(QUANTRA_HOMEDIR)

    parser.set_defaults(func=quantra_main)
    args = parser.parse_args()

    if not (psw:=os.environ.get('QUANTRA_APP_PSW')):
        psw = getpass.getpass("Please, input application password:")
        if not psw:
            print("Empty password is detected and not acceptable!")
            sys.exit(1)
    args.psw = psw

    setup_logger(args.verbose, args.logdir, args.device)

    if not os.path.exists(args.config):
        cfg = do_input_initial_cfg(CONFIG_OPTS)
        config_save(cfg, args.config, args.psw)

    cfg = config_read(args.config, args.psw)

    args.func(args, cfg, log)

    sys.exit(0)
