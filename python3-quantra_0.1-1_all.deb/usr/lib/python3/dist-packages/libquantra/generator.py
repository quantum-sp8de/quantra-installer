from abc import ABC, abstractmethod
import random
import time
import logging
import numpy
import subprocess
from quantralib.cipher import xor_crypt_encode, generate_dynamic_key

log = logging.getLogger('quantra')


class RandomGenerator(ABC):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        self.chain = chain_obj
        self.account = pubkey_account
        self.key = None
        self.last_tcheckpoint = None
        self.upinterval = update_interval

    @abstractmethod
    def _generate(self):
        pass

    def check_time_passed(self):
        # first run
        if not self.last_tcheckpoint:
            return True
        tcurrent = time.time()
        if (tcurrent - self.last_tcheckpoint) >= self.upinterval:
            return False

        return True

    def generate(self):
        encrypted = None
        value = self._generate()
        if not self.key or not self.check_time_passed():
            # set new dynpubkey for account and reload timer
            self.last_tcheckpoint = time.time()
            self.key = generate_dynamic_key()
            self.chain.set_dynamic_encrypt_pubkey(self.account, self.key)
            log.debug("Re-set dynamic dynpubkey in chain to value: %s" % self.key)
        else:
            self.key = self.chain.get_dynamic_encrypt_pubkey(self.account)
            log.debug("Using value of dynpubkey from the chain: %s" % self.key)

        encrypted = xor_crypt_encode(str(value), self.key)

        return encrypted

class RandomGeneratorQuantis(RandomGenerator):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)
        try:
            from .quantis import QUANTIS
        except Exception as ex:
            log.error(ex)
            raise RuntimeError("QUANTIS hardware is not available") from None

        self.qrandom = QUANTIS()

    def _generate(self):
        a = self.qrandom.get_bits(16)
        return a.dot(1 << numpy.arange(a.size)[::-1])

class RandomGeneratorUrandom(RandomGenerator):
    def _generate(self):
        return random.randint(0, 65536)

class RandomGeneratorQuantisRemote(RandomGenerator):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)

        try:
            self.ssh_user = kwargs["ssh_user"]
            self.ssh_host = kwargs["ssh_host"]
            self.ssh_pass = kwargs["ssh_pass"]
        except KeyError:
            raise RuntimeError("One of the ssh_user, ssh_host or ssh_pass hasn't been provided in config") from None

    def _generate(self):
        r = subprocess.run("sshpass -p {} ssh -o 'StrictHostKeyChecking no' {}@{} ssh_random".format(self.ssh_pass,
                                                                       self.ssh_user,
                                                                       self.ssh_host),
                                                                       shell=True,
                                                                       stdout=subprocess.PIPE)
        if r.returncode != 0:
            raise RuntimeError("Unable to get random from QUANTIS remotely. Please, check your ssh/sshpass, host and user creds")

        str_short = r.stdout.decode().strip()
        return int(str_short)

RandomGeneratorFactory = {
    "quantis": RandomGeneratorQuantis,
    "ssh_quantis": RandomGeneratorQuantisRemote,
    "pseudo": RandomGeneratorUrandom,
}
