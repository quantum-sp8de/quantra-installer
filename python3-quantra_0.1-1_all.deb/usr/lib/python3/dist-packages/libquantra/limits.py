__all__ = ["LimitsAggregator"]

import time
import logging

log = logging.getLogger('quantra')


class Limit:
    def refresh_cfg_label(self, config_param):
        '''
        Updates the limit value from config if changed
        '''
        raise NotImplemeted

    def check_limit(self, config_param, **params):
        '''
        returns:
        True - if has not been reached
        False - otherwise
        '''
        raise NotImplemetedError

class TimeLimit(Limit):
    CFG_LABEL = "time_limit"

    def refresh_cfg_label(self, time_limit):
        if time_limit is None:
            time_limit = -1
        # convert input str of hours to float of sec
        tl = float(time_limit) * 60 * 60
        if tl != self.time_limit:
            # reload timer for the new value
            self.time_limit = tl
            self.start_timer = time.time()

        return tl

    def __init__(self, time_limit):
        self.time_limit = None
        self.refresh_cfg_label(time_limit)

    def check_limit(self, time_limit, **params):
        tl = self.refresh_cfg_label(time_limit)

        if tl < 0:
            # unlimited by the time
            log.debug("Unlimited by the time execution")
            return True
        if tl == 0:
            log.debug("Time limit: stop activated by the user")
            return False
        t_diff = tl - (time.time() - self.start_timer)
        if t_diff <= 0:
            log.info("The time limit has been reached")
            return False
        else:
            log.debug("There are %s sec left for running transactions" % t_diff)

        return True

class CPULimit(Limit):
    CFG_LABEL = "cpu_limit"

    def refresh_cfg_label(self, cpu_limit):
        if cpu_limit is None:
            cpu_limit = -1
        self.cpu_limit = int(cpu_limit)

    def __init__(self, cpu_limit):
        self.cpu_limit = None
        self.refresh_cfg_label(cpu_limit)

    def check_limit(self, cpu_limit, **params):
        self.refresh_cfg_label(cpu_limit)
        if self.cpu_limit < 0:
            log.debug("There is no CPU limit for transactions")
            return True

        cpu_value = params.get('cpu_value')
        if cpu_value is None:
            log.error("cpu_value (from transaction) has not been found while checking cpu limit")
            raise RuntimeError("Can not continue, no value for CPU limit has been provided")
        if cpu_value >= self.cpu_limit:
            log.info('CPU limit has been reached, (%s) with limit of %s us' % (cpu_value, self.cpu_limit))
            return False

        return True

class NetLimit(Limit):
    CFG_LABEL = "net_limit"

    def refresh_cfg_label(self, net_limit):
        if net_limit is None:
            net_limit = -1
        self.net_limit = int(net_limit)

    def __init__(self, net_limit):
        self.net_limit = None
        self.refresh_cfg_label(net_limit)

    def check_limit(self, net_limit, **params):
        self.refresh_cfg_label(net_limit)
        if self.net_limit < 0:
            log.debug("There is no NET limit for transactions")
            return True

        net_value = params.get('net_value')
        if net_value is None:
            log.error("net_value (from transaction) has not been found while checking net limit")
            raise RuntimeError("Can not continue, no value for NET limit has been provided")
        if net_value >= self.net_limit:
            log.info('NET limit has been reached, (%s) with limit of %s bytes' % (net_value, self.net_limit))
            return False

        return True

class LimitsAggregator:
    def __init__(self, config):
        self.limits = [cl(config[cl.CFG_LABEL]) for cl in LIMITS]

    def check_limits(self, config, **params):
        return all( ( l.check_limit(config[l.CFG_LABEL], **params) for l in self.limits) )


# Just register your Limit subclass here
LIMITS = [TimeLimit, CPULimit, NetLimit,]
