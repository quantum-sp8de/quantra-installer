import os
import sys
import yaml
import logging
import collections

from .cipher import AESCipher


log = logging.getLogger('quantra')

CONFIG_OPTS = [
    "account",
    "tokens_account",
    "contract_account",
    "url",
    "private_key",
    "transaction_timer",
    "cpu_limit",
    "net_limit",
    "time_limit",
    "ssh_host",
    "ssh_user",
    "ssh_pass"
]

def check_config_opts(cfg):
    if not cfg:
        msg = "The config file is empty"
        log.error(msg)
        raise RuntimeError(msg)

    for c in ["transaction_timer", "cpu_limit", "net_limit", "time_limit"]:
        try:
            val = cfg.get(c)
            if val is None and "limit" in c:
                continue
            int(val)
        except ValueError:
            msg = "Unsupported type for %s,value '%s' must be an integer" % (c, cfg.get(c))
            log.error(msg)
            raise RuntimeError(msg) from None

    for c in ["private_key",]:
        if not cfg.get(c):
            msg = "The option %s must exist and be non-empty" % c
            log.error(msg)
            raise RuntimeError(msg) from None

    for c in ["account", "tokens_account", "contract_account",]:
        val = cfg.get(c)
        if not val or len(val) != 12:
            msg = "The option %s must exist, be non-empty and contain 12 chars" % c
            log.error(msg)
            raise RuntimeError(msg) from None

    for c in ["url",]:
        if not c in cfg:
            msg = "Missing option %s in config file" % c
            log.error(msg)
            raise RuntimeError(msg) from None

def config_read(path, cipher_key):
    '''
    Reads the config file from the path
    Config file can not be empty
    '''
    log.debug("Reading config file from %s" % path)

    cfg = {}
    if os.path.exists(path):
        with open(path) as f:
            data = f.read().strip()
            if data:
                if hasattr(yaml, 'FullLoader'):
                    cfg = yaml.load(data, Loader=yaml.FullLoader)
                else:
                    cfg = yaml.load(data)

    check_config_opts(cfg)

    if cfg.get('private_key'):
        c = AESCipher(cipher_key)
        dec_key = c.decrypt(cfg['private_key'])
        if not dec_key:
            log.error("Can not decrypt configuration value with password provided, some of them are broken.")
            sys.exit(1)
        else:
            cfg['private_key'] = dec_key.decode()

    log.debug(cfg)

    return collections.defaultdict(lambda: None, cfg)

def config_save(cfg, path, cipher_key):
    if cfg.get('private_key', None):
        c = AESCipher(cipher_key)
        cfg['private_key'] = c.encrypt(cfg['private_key']).decode()

    with open(path, 'w') as f:
        f.write(yaml.dump(cfg))
