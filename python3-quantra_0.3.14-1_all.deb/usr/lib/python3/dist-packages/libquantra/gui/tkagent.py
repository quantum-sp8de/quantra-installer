__all__ = ['gui_main',]

import os
import time
import argparse
import threading
import logging
import tkinter as tk

from logging.handlers import RotatingFileHandler
from collections import namedtuple
from tkinter import ttk
from tkinter import simpledialog
from tkinter import scrolledtext

from ..config import config_read, config_save, CONFIG_OPTS, ConfigError
from ..config import ConfigError, ConfigDecryptError, ConfigEmptyError
from ..main import quantra_main, QUANTRA_HOMEDIR


CONFIG_READ_ATTEMPTS=3


# indicated pressing cancel button
class CancelError(Exception): pass

AppArgs = namedtuple('AppArgs', ['random', 'config', 'psw'])


class ScrolledTextHandler(logging.Handler):

    def __init__(self, tk_text, clear_msg_count=5000):
        logging.Handler.__init__(self)
        self.text = tk_text
        self.msg_count = 0
        self.clear_msg_count = clear_msg_count

    def _append_cb(self, msg, clear):
        self.text.configure(state='normal')
        # app may run very long, so prevent
        # widget's possible memory overloading
        # with clearing widget after X msg count
        if clear:
            self.text.delete(1.0, tk.END)
        self.text.insert(tk.END, msg + '\n')
        self.text.configure(state='disabled')
        self.text.yview(tk.END)

    def emit(self, record):
        clear = False
        self.msg_count += 1

        msg = self.format(record)

        if self.msg_count >= self.clear_msg_count:
             clear = True
             self.msg_count = 0

        # schedule callback in main tk event loop
        self.text.after(0, lambda: self._append_cb(msg, clear))

class QuantraAppTk:
    def __init__(self, cfg_path, logdir, debug, random, title="quantra"):
        self.root = tk.Tk()
        self.root.title(title)

        self.config_path = cfg_path
        self.log_dir = logdir
        self.debug_flag = debug
        self.random = random

        self.gen_stop_event = threading.Event()
        self.gen_stop_event.set()
        self.psw = None
        self.cfg = {}
        self.gen_thread = None

        self._setup_layout()
        # setup watcher for config changes
        self.root.after(1, self._config_changed_watcher)

        self.log = logging.getLogger(title)
        self._setup_logger()

        self._load_app_configuration()

        # correctly shutdown generator on quit
        self.root.protocol('WM_DELETE_WINDOW', self._on_quit_callback)

    ##### layout

    def _setup_layout(self):
#        self.root.geometry('800x600')
#        self.root.resizable(0, 0)
        # layout on the root window
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure(1, weight=1)

        self.input_frame = self._create_info_frame()
        self.input_frame.grid(column=0, row=0, sticky=tk.NW)

        self.log_frame = self._create_log_frame()
        self.log_frame.grid(column=1, row=0, sticky="nsew")

        self.cfg_manage_frame = self._create_config_manage_frame()
        self.cfg_manage_frame.grid(column=0, row=1, sticky=tk.SW)

        self.manage_frame = self._create_manage_frame()
        self.manage_frame.grid(column=1, row=1, sticky=tk.SE)


    def _create_info_frame(self):
        frame = ttk.Frame(self.root, name='info_frame')

        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=2)

        for i, (name, text) in enumerate(CONFIG_OPTS):
            ttk.Label(frame, text=text).grid(column=0, row=i, sticky=tk.W, padx=5, pady=5)
            e = ttk.Entry(frame, name=name, width=30)
            e.grid(column=1, row=i, sticky=tk.W, padx=5, pady=5)

        self.root.nametowidget("info_frame.private_key").config(show="*")

        return frame

    def _create_log_frame(self):
        frame = ttk.Frame(self.root, name='log_frame')

        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        st = scrolledtext.ScrolledText(frame, name='plog', state='disabled')
        st.grid(column=0, row=0, sticky=tk.EW, padx=5, pady=5)

        return frame

    def _create_manage_frame(self):
        frame = ttk.Frame(self.root, name='manage_frame')

        frame.columnconfigure(0, weight=1)

        ttk.Button(frame, name='run', text='Run', command=self._on_run_button_callback).grid(column=1, row=0)
        ttk.Button(frame, name='stop', text='Stop', command=self._on_stop_button_callback).grid(column=2, row=0)

        for widget in frame.winfo_children():
            widget.grid(padx=5, pady=5)

        return frame

    def _create_config_manage_frame(self):
        frame = ttk.Frame(self.root, name="cfg_manage_frame")

        label = ttk.Label(frame, name='reload_config',
                          text="Some of configuration values have been changed. Press 'Run' to reload config")
        label.grid(column=0, row=0, padx=5, pady=5)
        label.grid_remove()

        return frame

    ##### callbacks

    def _on_run_button_callback(self):
        # store and read again, so we validate cfg integrity

        self.log.info("Reloading user configuration")
        cfg = self._gui_to_config()

        config_save(cfg, self.config_path, self.psw)
        self.root.nametowidget("cfg_manage_frame.reload_config").grid_remove()

        try:
            self.cfg = config_read(self.config_path, self.psw)
        except ConfigError as ex:
            tk.messagebox.showerror(title="Configuration error", message=ex)
            # mark config as invalid value, cause it broken anyway
            self.cfg = None
            # good luck to try next time
            return

        self._run_generation_thread()

    def _on_stop_button_callback(self):
        self._stop_generation_thread()

    def _on_quit_callback(self):
        self._stop_generation_thread()
        self.root.destroy()

    ##### main application logic

    def _config_changed_watcher(self):
        '''Watch if any config value is changed in gui'''

        label =  self.root.nametowidget("cfg_manage_frame.reload_config")
        if self.cfg:
            new_cfg = self._gui_to_config()
            if self.cfg != new_cfg:
                label.grid()
            else:
                label.grid_remove()
        self.root.after(1, self._config_changed_watcher)

    def _config_to_gui(self):
        '''Adjust gui elements with configuration data'''

        for prop in (x[0] for x in CONFIG_OPTS):
            entry = self.root.nametowidget("info_frame.%s" % prop)
            entry.delete(0, tk.END)
            entry.insert(0, self.cfg[prop])

    def _gui_to_config(self):
        '''Adjust local configuration file with by values in gui elements'''

        cfg = {}
        for prop in (x[0] for x in CONFIG_OPTS):
            entry = self.root.nametowidget("info_frame.%s" % prop)
            cfg[prop] = entry.get()

        return cfg

    def _stop_generation_thread(self):
        if self.gen_stop_event.is_set():
            return

        self.gen_stop_event.set()

        while self.gen_thread and self.gen_thread.is_alive():
            # omg, hours of debugging...
            self.root.update()

        self.gen_thread = None

    def _run_generation_thread(self):

        args=AppArgs(self.random, self.config_path, self.psw)

        self._stop_generation_thread()
        self.gen_stop_event.clear()
        self.gen_thread = threading.Thread(target=quantra_main, args=[args, self.cfg, self.log, self.gen_stop_event])
        self.gen_thread.start()

    def _generation_is_runnning(self):
        is_running = self.gen_thread and self.gen_thread.is_alive()
        if not is_running:
            # just in case of generator self-exit
            # adjust stop event
            self.gen_stop_event.set()

        return is_running

    def _get_app_password(self):
        self.root.withdraw()
        self.psw = simpledialog.askstring("Authorization", "Input application password", show="*")
        self.root.deiconify()

        return self.psw

    def _load_app_configuration(self, total_attempts=CONFIG_READ_ATTEMPTS):
        ''' Reading/checking application config'''

        for attempt in range(total_attempts):
            try:
                self._get_app_password()
                # user pressed cancel, immediately exit
                if self.psw is None:
                    raise CancelError("Canceled by user")
                self.cfg = config_read(self.config_path, self.psw)
                break
            except CancelError as ex:
                raise
            except ConfigDecryptError:
                if attempt >= 2:
                    tk.messagebox.showerror(title="Access denied", message="Invalid application password")
                    raise
            except ConfigEmptyError:
                tk.messagebox.showwarning(title="Configuration is incomplete",
                                          message="Cached config not found, please enter all config fields and press 'Run'")
                return
            except ConfigError as ex:
                details = "Your config file in %s has an error. %s" % (self.config_path, ex)
                self.log.error(details)
                return

        self._config_to_gui()

    def _setup_logger(self):
        self.log.setLevel(logging.DEBUG)

        level = logging.INFO
        fmt = logging.Formatter('%(asctime)s: %(message)s')
        fmt_debug = logging.Formatter('%(asctime)s:%(levelname)s:%(filename)s:%(lineno)d: %(message)s')
        if self.debug_flag:
            level = logging.DEBUG
            fmt = fmt_debug

        # setup gui handler
        st = self.root.nametowidget("log_frame.!frame.plog")
        sh = ScrolledTextHandler(st)
        sh.setLevel(level)
        sh.setFormatter(fmt)
        self.log.addHandler(sh)

        sh = logging.StreamHandler()
        sh.setLevel(logging.DEBUG)
        sh.setFormatter(fmt)
        self.log.addHandler(sh)

        fh = RotatingFileHandler(os.path.join(self.log_dir,'quantra.log'), mode='a',
                                 maxBytes=500*1024*1024,
                                 backupCount=2, encoding=None, delay=0)
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(fmt_debug)
        self.log.addHandler(fh)

    def run(self):
        self.root.mainloop()


def gui_main():
    '''Main tkinter gui function'''

    parser = argparse.ArgumentParser(prog='quantra-gui')
    parser.add_argument('-c','--config', help='configuration file to be used for the program', default=os.path.join(QUANTRA_HOMEDIR,"quantra.yaml"))
    parser.add_argument('-v','--verbose', help='print additional debug information', action='store_true', default=False)
    parser.add_argument('-l','--logdir', help='directory with log file', default=QUANTRA_HOMEDIR)
    parser.add_argument('-d','--device', help='path to QCicada device', default=QCICADA_DEVICE)
    parser.add_argument('-r','--random',
                        required=True,
                        help='use OS random features instead of quantis library',
                        choices=['system', 'quantis', 'qcicada'],)

    if not os.path.exists(QUANTRA_HOMEDIR):
        os.mkdir(QUANTRA_HOMEDIR)

    args = parser.parse_args()

    app = QuantraAppTk(cfg_path=args.config, logdir=args.logdir, random=args.random, debug=args.verbose)
    app.run()
