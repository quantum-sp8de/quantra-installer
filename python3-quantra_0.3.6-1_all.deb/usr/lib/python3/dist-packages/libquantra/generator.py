from abc import ABC, abstractmethod
import hashlib
import os
import random
import time
import logging
import numpy
import subprocess
import requests
import struct
from requests.exceptions import HTTPError
from quantralib.cipher import xor_crypt_encode, generate_dynamic_key
from quantralib.keys import sig_to_eossig
from .qcicada_qcc import qrng_cmdctrl_qcicada

log = logging.getLogger('quantra')

QUANTIS_ON_FAIL_RETRIES = 60
QUANTIS_BUFFER_SIZE = 4096
UINT_MAX = 2**32-1
# TODO: move to cmd args in case we need to configure this
QCICADA_DEVICE='/dev/ttyUSB0'


class QCicadaGenerationError(Exception): pass

class RandomGenerator(ABC):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        self.chain = chain_obj
        self.account = pubkey_account
        self.key = None
        self.last_tcheckpoint = None
        self.upinterval = update_interval

    @abstractmethod
    def _generate(self):
        pass

    def check_time_passed(self):
        # first run
        if not self.last_tcheckpoint:
            return False
        tcurrent = time.time()
        if (tcurrent - self.last_tcheckpoint) >= self.upinterval:
            return False

        return True

    def reset_dynamic_keys(self):
        # re-reading is required because we can continue after stop
        old_key = self.chain.get_dynamic_encrypt_pubkey(self.account)
        if old_key:
            self.chain.set_dynamic_backup_pubkey(self.account, old_key)
        self.key = generate_dynamic_key()
        self.chain.set_dynamic_encrypt_pubkey(self.account, self.key)
        log.debug("Re-set dynamic dynpubkey in chain to value: %s" % self.key)

    def generate(self):
        encrypted = None
        value, signature, digest = self._generate()
        if not self.key or not self.check_time_passed():
            # set new dynpubkey for account and reload timer
            self.last_tcheckpoint = time.time()
            self.reset_dynamic_keys()
        else:
            self.key = self.chain.get_dynamic_encrypt_pubkey(self.account)
            log.debug("Using value of dynpubkey from the chain: %s" % self.key)

        encrypted = xor_crypt_encode(str(value), self.key)

        return encrypted, signature, digest


class RandomGeneratorQCicada(RandomGenerator):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)

        try:
            self.cc = qrng_cmdctrl_qcicada("serial", QCICADA_DEVICE)
            self.device_pubkey = self.cc.get_dev_auth_pubkey()
        except Exception as ex:
            log.error(ex)
            raise RuntimeError("QCicada QRNG hardware is not available, please, insert it") from None

    def _generate(self):

        reading = self.cc.read_signed(2)
        if reading is None:
            raise QCicadaGenerationError('QCicada generated empty output!')

        data = reading['qrnd']
        signature = reading['signature']

#        print("Data: " + data.hex())
#        print("Signature: " + signature.hex())

        # TODO: little ending or big endian
        r = int(data[0])
        r = (r << 8) + int(data[1])

        m = hashlib.sha256()
        m.update(data)

        log.debug(f"Signature is {signature.hex()}")
        log.debug(f"Device pubkey is {self.device_pubkey.hex()}")
        log.debug(f"Data is {data.hex()}")

        eos_sig = sig_to_eossig(signature.hex(), self.device_pubkey.hex(), data.hex())
        log.debug(f"Converted to sig: {eos_sig}")

        return r, eos_sig, m.hexdigest()


RandomGeneratorFactory = {
    "qcicada": RandomGeneratorQCicada,
}
