import time
import sys
import logging
import requests
import random
import json
import urllib

from requests.exceptions import HTTPError
from qcrypgrapher import encrypt, decrypt

log = logging.getLogger('quantra')


class KeyFetcher:
    '''
    Keyfetcher provides interfaces for retriving and manipulating
    of random key from special service,
    which is used to cipher random values in quantra transactions
    '''

    def _init_quantis_device(self):
        '''
        The quantis support is limited by USB type here at the moment
        '''
        try:
            from .quantis import QuantisGetSerialNumber, QUANTIS_DEVICE_USB
            self.serial = QuantisGetSerialNumber(QUANTIS_DEVICE_USB, 0).decode()
        except Exception as ex:
            log.error(ex)
            raise RuntimeError("QUANTIS hardware is not available") from None

    def __init__(self, key_service_url, random_type, account, chain_obj, update_interval=3600):
        self.chain = chain_obj
        self.account = account
        self.key_service_url = urllib.parse.urljoin(key_service_url, '/genkey')
        self.last_tcheckpoint = None
        self.upinterval = update_interval
        self.random_type = random_type
        if self.random_type == 'quantis':
            self._init_quantis_device()
        self.key = None
        self._random = random.SystemRandom()

    def get_serial_value(self):
        ret = None
        if self.random_type == 'system':
            ret = encrypt('system_random')
        elif self.random_type == 'quantis':
            ret = encrypt(self.serial)
        # TODO: figure out how to get unique serial or whatever
        elif self.random_type == 'qcicada':
            ret = encrypt('qcicada_random')
        else:
            raise RuntimeError("Invalid random producer type has been provided")

        return ret

    def retrive_key(self):
        key_obj = None
        data = {'generator': self.account, 'serial': self.get_serial_value()}
        headers = {'Content-Type': 'application/json'}
        resp = requests.post(self.key_service_url, data=json.dumps(data), headers=headers)
        try:
            resp.raise_for_status()
        except HTTPError as ex:
            log.warning("Can not retrive random cipher key from key server at the moment.")
            log.warning(ex)
            return key_obj

        key_obj = resp.json()['key']
        return key_obj

    def generate(self):
        if not self.check_if_enabled():
            self.key = None
            log.debug("Re-set key of random to null")
            return self.key
        else:
            if not self.check_time_passed():
                key_obj = self.retrive_key()
                if not key_obj:
                    self.key = None
                    log.debug("Re-set key of random to null because of key server errors")
                    return self.key
                decrypt_times = self.get_decrypt_count()
                for x in range(decrypt_times):
                    key_obj = decrypt(key_obj)

                if len(key_obj) != 9:
                    er = "Decrypted key has invalid lenght {}. Aborting".format(len(key_obj))
                    log.error(er)
                    # just an instant exit, this is serious program bug
                    sys.exit(1)
                self.key = key_obj
                self.last_tcheckpoint = time.time()
                log.debug('Re-set key of random to {}***'.format(self.key[:3]))

        log.debug("Using key of random: {}***".format(self.key[:3]))

        return self.gen_pin(self.key)

    def get_decrypt_count(self):
        cfg = self.chain.get_config_keystable()
        return cfg['rows'][0]['level_encrypt']

    def check_if_enabled(self):
        return self.get_decrypt_count() > 0

    def check_time_passed(self):
        # first run
        if not self.last_tcheckpoint:
            return False
        tcurrent = time.time()
        if (tcurrent - self.last_tcheckpoint) >= self.upinterval:
            return False

        return True

    def gen_pin(self, key):
        i1 = self._random.randint(0,8)

        pin = (key+key)[i1:i1+3]
        return encrypt(pin)
