import base64
import hashlib
import string
from Cryptodome.Cipher import AES


class AESCipher:
    '''AES with 16 bit key'''
    def __init__(self, key):
        digest = hashlib.sha256(self._tobytes(key)).digest()
        self.key = digest[:AES.block_size]
        self.nonce = digest[-AES.block_size:]
        self.cipher = AES.new(self.key, AES.MODE_EAX, self.nonce)

    def _tobytes(self, key):
        b_key = key
        if isinstance(key, str):
            b_key = key.encode()
        elif isinstance(key, bytes):
            pass
        else:
            raise RuntimeError("Unsupported key type: %s" % type(key))

        return b_key

    def encrypt(self, msg):
        c_text, tag = self.cipher.encrypt_and_digest(self._tobytes(msg))
        # to decodable ascii/utf-8 string
        return base64.b64encode(tag+c_text)

    def decrypt(self, msg):
        data = base64.b64decode(self._tobytes(msg))
        tag, emsg = data[:AES.block_size], data[AES.block_size:]
        cipher = AES.new(self.key, AES.MODE_EAX, nonce=self.nonce)
        text = cipher.decrypt(emsg)
        try:
            cipher.verify(tag)
        except ValueError:
            text = None

        return text

if __name__ == "__main__":
    o = AESCipher('Hello my key!')
    msg = "I am some message from the user hohoho!@#>? س¤tT{æꞍꝹ"
    print("Original message is: %s" % msg)
    e_msg = o.encrypt(msg)
    print("Encrypted message is: %s " % e_msg)
    msg_back = o.decrypt(e_msg)
    print("Decrypted message is: %s" % msg_back.decode())
    print("Messages are the same: %s" % (msg == msg_back.decode()))
