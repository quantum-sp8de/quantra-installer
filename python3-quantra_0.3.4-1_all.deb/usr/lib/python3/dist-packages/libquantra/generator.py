from abc import ABC, abstractmethod
import os
import random
import time
import logging
import numpy
import subprocess
import requests
import struct
from requests.exceptions import HTTPError
from quantralib.cipher import xor_crypt_encode, generate_dynamic_key

log = logging.getLogger('quantra')

QUANTIS_ON_FAIL_RETRIES = 60
QUANTIS_BUFFER_SIZE = 4096
UINT_MAX = 2**32-1
# TODO: figure out better way to get library location
PYKCS11LIB = os.environ.setdefault('PYKCS11LIB', "/opt/qrng/cicada-pkcs11.so")

class RandomGenerator(ABC):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        self.chain = chain_obj
        self.account = pubkey_account
        self.key = None
        self.last_tcheckpoint = None
        self.upinterval = update_interval

    @abstractmethod
    def _generate(self):
        pass

    @abstractmethod
    def generate_uint_list(self, size):
        if not isinstance(size, int) or size <= 0:
            raise RuntimeError("Invalid size in generate_uint_list(): must be int > 0")

    def check_time_passed(self):
        # first run
        if not self.last_tcheckpoint:
            return False
        tcurrent = time.time()
        if (tcurrent - self.last_tcheckpoint) >= self.upinterval:
            return False

        return True

    def reset_dynamic_keys(self):
        # re-reading is required because we can continue after stop
        old_key = self.chain.get_dynamic_encrypt_pubkey(self.account)
        if old_key:
            self.chain.set_dynamic_backup_pubkey(self.account, old_key)
        self.key = generate_dynamic_key()
        self.chain.set_dynamic_encrypt_pubkey(self.account, self.key)
        log.debug("Re-set dynamic dynpubkey in chain to value: %s" % self.key)

    def generate(self):
        encrypted = None
        value = self._generate()
        if not self.key or not self.check_time_passed():
            # set new dynpubkey for account and reload timer
            self.last_tcheckpoint = time.time()
            self.reset_dynamic_keys()
        else:
            self.key = self.chain.get_dynamic_encrypt_pubkey(self.account)
            log.debug("Using value of dynpubkey from the chain: %s" % self.key)

        encrypted = xor_crypt_encode(str(value), self.key)

        return encrypted

class RandomGeneratorQuantis(RandomGenerator):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)
        try:
            from .quantis import quantis_read, QuantisReadError
            self.quantis_read = quantis_read
            self.QuantisReadError = QuantisReadError
        except Exception as ex:
            log.error(ex)
            raise RuntimeError("QUANTIS hardware is not available") from None

        self.quantis_buffer = []

    def _generate(self):
        if len(self.quantis_buffer) == 0:
            # reading may block other clients while doing op, so keep attempts here
            for _ in range(QUANTIS_ON_FAIL_RETRIES):
                log.debug("Trying to read buffer from quantis device")
                try:
                    self.quantis_buffer = self.quantis_read(QUANTIS_BUFFER_SIZE)
                    break
                except self.QuantisReadError as ex:
                    log.warning("Quantis reading failed with reason: %s" % ex)
                    time.sleep(1)
            else:
                raise RuntimeError("Can not read data from quantis device")

        r = self.quantis_buffer.pop()
        r = (r << 8) + self.quantis_buffer.pop()

        return r

    def generate_uint_list(self, size):
        super().generate_uint_list(size)
        ret = []
        attempts = 1000

        # to prevent infinite loop
        for _ in range(size*attempts):
            l = self.quantis_read(size*4)
            for i in range(0, len(l), 4):
                test_value = struct.unpack("I", bytes(l[i:i+4]))[0]
                ret.append(test_value)
                if len(ret) == size:
                    return ret

        raise RuntimeError("Failed to generate uint list of randoms using Quantis")

class RandomGeneratorUrandom(RandomGenerator):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)
        self.urandom = random.SystemRandom()

    def _generate(self):
        return self.urandom.randint(0, 65536)

    def generate_uint_list(self, size):
        super().generate_uint_list(size)
        return [self.urandom.randint(0, UINT_MAX) for _ in range(size)]

class RandomGeneratorQCicada(RandomGenerator):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)

        try:
            global PyKCS11
            import PyKCS11

            self.pkcs11 = PyKCS11.PyKCS11Lib()
            self.pkcs11.load() # affected by env PYKCS11LIB
            self.slot = self.pkcs11.getSlotList(tokenPresent=True)[0]
        except Exception as ex:
            log.error(ex)
            raise RuntimeError("QCicada QRNG hardware is not available") from None

    def _generate(self):
        session = None
        try:
            session = self.pkcs11.openSession(self.slot, PyKCS11.CKF_SERIAL_SESSION | PyKCS11.CKF_RW_SESSION)
            generated = session.generateRandom(2)
            r = generated.pop()
            r = (r << 8) + generated.pop()
        except Exception as ex:
            log.error(ex)
            raise RuntimeError("QCicada QRNG hardware error while generating") from None
        finally:
            if session:
                session.closeSession()

        return r

    def generate_uint_list(self, size):
        super().generate_uint_list(size)
        session = None
        ret = []
        try:
            session = self.pkcs11.openSession(self.slot, PyKCS11.CKF_SERIAL_SESSION | PyKCS11.CKF_RW_SESSION)
            l = session.generateRandom(size*4)
            for i in range(0, len(l), 4):
                test_value = struct.unpack("I", bytes(l[i:i+4]))[0]
                ret.append(test_value)
                if len(ret) == size:
                    return ret
        except Exception as ex:
            log.error(ex)
            raise RuntimeError("QCicada QRNG hardware error while generating") from None
        finally:
            if session:
                session.closeSession()

class RandomGeneratorQRNG(RandomGenerator):
    '''IBM Qiskit qrng integration'''

    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)
        try:
            import qrng
            qrng.set_provider_as_IBMQ(kwargs['qrng_token'])
            qrng.set_backend(kwargs['qrng_backend'])
        except Exception as ex:
            log.error(ex)
            raise RuntimeError("QRNG support is not available") from None

        self.genobj = qrng

    def _generate(self):
        return self.genobj.get_random_int32() & 0x0000ffff

    def generate_uint_list(self, size):
        # NOTE: currently (u)int32 only
        if ML_MAX_VAL == 2**32-1:
            return [self.genobj.get_random_int32() for _ in range(size)]
        else:
            raise RuntimeError("QRNG generator does not support generating values not in 0...2^32 range") from None

RandomGeneratorFactory = {
    "qcicada": RandomGeneratorQCicada,
    "quantis": RandomGeneratorQuantis,
    "system": RandomGeneratorUrandom,
}
