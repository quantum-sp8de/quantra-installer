#!/usr/bin/env python3

import os
import sys
import argparse
import getpass
import time
import traceback
import threading
from requests.exceptions import ConnectionError, HTTPError, ReadTimeout

from quantralib.erandom import EOSRandom
from .config import config_read, config_save, CONFIG_OPTS
from .limits import *
from .generator import RandomGeneratorFactory
from .keyfetcher import KeyFetcher


def quantra_main(args, cfg, log, stop_event=threading.Event()):
    """ Main quantra logic processing point """

    try:
        chain = EOSRandom(cfg['contract_account'],
                          p_keys=cfg['private_key'],
                          tokens_account=cfg['tokens_account'],
                          chain_url=cfg['url'], chain_port=None)

        value_generator = RandomGeneratorFactory[args.random](chain, cfg['account'], **cfg)

        is_valid = chain.check_if_validator(cfg['account'])
        if is_valid:
            log.info("Account '%s' has been already registered as generator" % cfg['account'])
        else:
            min_depos = chain.get_minimal_deposit()
            if not min_depos:
                er_msg = "Unable to get minimal deposit for generator registration, aborting"
                log.error(er_msg)
                raise RuntimeError(er_msg)

            # TODO: change to sane name
            registered = chain.register_as_validator(cfg['account'], min_depos)
            if not registered:
                er_msg = "Fail to register '%s' as a generator. Check logs for more info" % cfg['account']
                log.error(er_msg)
                raise RuntimeError(er_msg)

        checker = LimitsAggregator(cfg)
        params = {'cpu_value': 0, 'net_value' : 0}

        keyf = KeyFetcher(key_service_url=cfg['key_url'],
                          random_type=args.random,
                          account=cfg['account'],
                          chain_obj=chain,
                          update_interval=3600)

    # early sane error msg
    except Exception as ex:
        log.debug(traceback.format_exc(chain=False))
        log.error(ex)
        raise SystemExit(ex)

    # retries counter for http error code 500 during workflow
    retries = 0
    while True:

        if retries >=3:
            log.error("Program is failed to fix broken state, aborting")
            sys.exit(1)
        try:
            if not checker.check_limits(cfg, **params):
                log.info("Limit is reached, exiting")
                break

            random_num = value_generator.generate()
            random_key = keyf.generate()
            res = chain.setrandom(random_num, cfg['account'], random_key)
            if not res:
                er_msg = "Failed to send random '%s', exiting" % random_num
                log.error(er_msg)
                raise RuntimeError(er_msg)
            else:
                log.info("Successfully pushed action with random value: '%s'" % random_num)
                params['cpu_value'] = res['processed']['receipt']['cpu_usage_us']
                params['net_value'] = res['processed']['receipt']['net_usage_words']

            stop_now = stop_event.wait(timeout=int(cfg['transaction_timer']))
            if stop_now:
                log.info("Program stop by user request")
                sys.exit(2)

            # workfow cycle is done - reset re-tries counter
            retries = 0
            # re-read config after every trasaction, live-checking
            # only changing limit params will result in any effect
            cfg = config_read(args.config, args.psw)
        except HTTPError as ex:
#            resp = ex.response.json()
            # only http code 500 is handled
            if ex.response.status_code == 500:
                log.warning(ex)
                log.warning("Retrying to fix workflow again ...")
                time.sleep(int(cfg['transaction_timer']))
            else:
                log.error(ex)
                sys.exit(1)
            retries+=1
        except ReadTimeout as ex:
            log.warn(ex)
            log.warn("Slow server response is detected, trying to fix it ...")
            time.sleep(int(cfg['transaction_timer']))
            retries+=1
        except ConnectionError as ex:
            log.debug(ex)
            log.warn("Network or host is unreachable. Trying to re-connect...")
            time.sleep(int(cfg['transaction_timer']))
        # do not print long cause tbs
        except Exception as ex:
            log.debug(traceback.format_exc(chain=False))
            log.error(ex)
            raise SystemExit(ex)
