import time
import sys
import logging
import requests
import random
import json
import urllib
from qcrypgrapher import encrypt, decrypt

log = logging.getLogger('quantra')


class KeyFetcher:
    def __init__(self, key_service_url, random_type, account, chain_obj, update_interval=3600):
        self.chain = chain_obj
        self.account = account
        self.key_service_url = urllib.parse.urljoin(key_service_url, '/genkey')
        self.last_tcheckpoint = None
        self.upinterval = update_interval
        # TODO: None or empty string?
        self.key = None
        self._random = random.SystemRandom()

    # TODO: temporary function, util only qrnx device
    # is only available in application
    # TODO: a stub for now
    def get_serial_value(self):
        return encrypt("0123456789abcdefgh")

    def retrive_key(self):
        data = {'generator': self.account, 'serial': self.get_serial_value()}
        headers = {'Content-Type': 'application/json'}
        resp = requests.post(self.key_service_url, data=json.dumps(data), headers=headers)
        if resp.status_code != 200:
            raise RuntimeError("Can not retrive key from key server. Reason:\n{}".format(resp.json()))

        return resp.json()['key']

    def generate(self):
        if not self.check_if_enabled():
            self.key = None
        else:
            if not self.check_time_passed():
                key_obj = self.retrive_key()
                decrypt_times = self.get_decrypt_count()
                for x in range(decrypt_times):
                    key_obj = decrypt(key_obj)

                if len(key_obj) != 9:
                    er = "Decrypted key has invalid lenght {}. Aborting".format(len(key_obj))
                    log.error(er)
                    # just an instant exit, this is serious program bug
                    sys.exit(1)
                self.key = key_obj
                self.last_tcheckpoint = time.time()
                log.debug('Re-set key of random to {}***'.format(self.key[:3]))

        log.debug("Using key of random: {}***".format(self.key[:3]))

        return self.gen_pin(self.key)

    def check_if_enabled(self):
        cfg = self.chain.get_config_keystable()
        return bool( cfg['rows'][0]['is_active'] )

    def get_decrypt_count(self):
        d_times = 1
        cfg = self.chain.get_config_keystable()
        if bool( cfg['rows'][0]['is_double_encrypt'] ):
            d_times = 2

        return d_times

    def check_time_passed(self):
        # first run
        if not self.last_tcheckpoint:
            return False
        tcurrent = time.time()
        if (tcurrent - self.last_tcheckpoint) >= self.upinterval:
            return False

        return True

    def gen_pin(self, key):
        i1 = self._random.randint(0,8)

        pin = (key+key)[i1:i1+3]
        return encrypt(pin)
