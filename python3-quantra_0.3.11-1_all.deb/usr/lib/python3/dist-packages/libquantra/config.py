import os
import sys
import yaml
import logging
import collections
import threading

from .cipher import AESCipher

# thread_safety on write/read ops
_config_lock = threading.Lock()

log = logging.getLogger('quantra')

# Containes the pairs of option and it's descriprion
CONFIG_OPTS = [
    ("account", "user account to operate within"),
    ("tokens_account", "account of tokens"),
    ("contract_account", "quantum-sp8de smart contract account"),
    ("url", "blockchain url"),
    ("key_url", "the url of random key guard service"),
    ("private_key", "private key for the user"),
    ("transaction_timer", "how often to send randoms, in seconds"),
    ("cpu_limit", "cpu limit to work within, in useconds"),
    ("net_limit", "net limit to work within, in bytes"),
    ("time_limit", "limit total execution time by value, in seconds"),
]


class ConfigError(Exception): pass
class ConfigDecryptError(ConfigError): pass
class ConfigEmptyError(ConfigError): pass


def print_debug_config(cfg):
    to_p = {k:v for k,v in cfg.items() if not 'private_key' in k}
    log.debug(to_p)

def check_config_opts(cfg):
    if not cfg:
        msg = "The config file is empty"
        log.error(msg)
        raise ConfigEmptyError(msg)

    for c in ["transaction_timer", "cpu_limit", "net_limit", "time_limit"]:
        try:
            val = cfg.get(c)
            if val is None and "limit" in c:
                continue
            int(val)
        except ValueError:
            msg = "Unsupported type for %s,value '%s' must be an integer" % (c, cfg.get(c))
            log.error(msg)
            raise ConfigError(msg) from None

    for c in ["private_key",]:
        if not cfg.get(c):
            msg = "The option %s must exist and be non-empty" % c
            log.error(msg)
            raise ConfigError(msg) from None

    for c in ["account", "tokens_account", "contract_account",]:
        val = cfg.get(c)
        if not val or len(val) > 12:
            msg = "The option %s must exist, be non-empty and contain not more then 12 chars" % c
            log.error(msg)
            raise ConfigError(msg) from None

    for c in ["url", "key_url",]:
        if not c in cfg:
            msg = "Missing option %s in config file" % c
            log.error(msg)
            raise ConfigError(msg) from None

def config_read(path, cipher_key):
    '''
    Reads the config file from the path
    Config file can not be empty
    '''
    log.debug("Reading config file from %s" % path)

    cfg = {}
    if os.path.exists(path):
        with _config_lock:
            with open(path) as f:
                data = f.read().strip()
                if data:
                    if hasattr(yaml, 'FullLoader'):
                        cfg = yaml.load(data, Loader=yaml.FullLoader)
                    else:
                        cfg = yaml.load(data)

    check_config_opts(cfg)

    if cfg.get('private_key'):
        c = AESCipher(cipher_key)
        dec_key = c.decrypt(cfg['private_key'])
        if not dec_key:
            msg="Can not decrypt configuration value with password provided, some of them are broken."
            raise ConfigDecryptError(msg)
        else:
            cfg['private_key'] = dec_key.decode()

    print_debug_config(cfg)

    return collections.defaultdict(lambda: None, cfg)

def config_save(cfg, path, cipher_key):
    cfg = cfg.copy()
    if cfg.get('private_key', None):
        c = AESCipher(cipher_key)
        cfg['private_key'] = c.encrypt(cfg['private_key']).decode()

    with _config_lock:
        with open(path, 'w') as f:
            f.write(yaml.dump(cfg))
