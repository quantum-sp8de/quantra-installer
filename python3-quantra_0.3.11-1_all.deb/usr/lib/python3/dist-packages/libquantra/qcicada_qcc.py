# QCicada Cmd&Ctrl extension class, implments custom commands
# Copytirhgt (C) 2024 Crypta Labs Ltd.
# Author: Davide Fogliano <davide@cryptalabs.com>
import sys
from .qcc import qrng_cmdctrl
import struct
import time

class qrng_cmdctrl_qcicada(qrng_cmdctrl):
  from cryptography.hazmat.primitives import serialization
  from cryptography.hazmat import backends
  from cryptography.hazmat.primitives.asymmetric import ec
  from cryptography.hazmat.primitives.asymmetric import utils
  from cryptography.hazmat.primitives import hashes
  from cryptography.exceptions import InvalidSignature

  CMDCTRL_CICADA_CMD_SET_AUTH = b'\xF0'
  CMDCTRL_CICADA_CMD_SET_ENC  = b'\xF1'
  CMDCTRL_CICADA_CMD_SET_SERIAL = b'\xF2'
  CMDCTRL_CICADA_CMD_SET_HW_REV  = b'\xF3'
  CMDCTRL_CICADA_CMD_SET_PROTOCOL_CA = b'\xF4'
  CMDCTRL_CICADA_CMD_SET_TARGET = b'\xF5'
  CMDCTRL_CICADA_CMD_SET_LED_LEVEL = b'\xF6'
  CMDCTRL_CICADA_CMD_GET_DEV_AUTH_PUBKEY = b'\xF7'
  CMDCTRL_CICADA_CMD_REBOOT = b'\xF8'
  CMDCTRL_CICADA_CMD_GET_DEV_CERTIFICATE = b'\xF9'
  
  CMDCTRL_CICADA_RESP_SET_OK = b'\xF8'
  CMDCTRL_CICADA_RESP_DEV_AUTH_PUBKEY = b'\xF9'
  CMDCTRL_CICADA_RESP_DEV_CERTIFICATE = b'\xFB'

  def __init__(self, interface, device_name):
    qrng_cmdctrl.__init__(self, interface, device_name)
    self._success_response[self.CMDCTRL_CICADA_CMD_SET_AUTH] = self.CMDCTRL_CICADA_RESP_SET_OK
    self._success_response[self.CMDCTRL_CICADA_CMD_SET_ENC] = self.CMDCTRL_CICADA_RESP_SET_OK
    self._success_response[self.CMDCTRL_CICADA_CMD_SET_SERIAL] = self.CMDCTRL_CICADA_RESP_SET_OK
    self._success_response[self.CMDCTRL_CICADA_CMD_SET_HW_REV] = self.CMDCTRL_CICADA_RESP_SET_OK
    self._success_response[self.CMDCTRL_CICADA_CMD_SET_PROTOCOL_CA] = self.CMDCTRL_CICADA_RESP_SET_OK
    self._success_response[self.CMDCTRL_CICADA_CMD_SET_TARGET] = self.CMDCTRL_CICADA_RESP_SET_OK
    self._success_response[self.CMDCTRL_CICADA_CMD_SET_LED_LEVEL] = self.CMDCTRL_CICADA_RESP_SET_OK
    self._success_response[self.CMDCTRL_CICADA_CMD_GET_DEV_AUTH_PUBKEY] = self.CMDCTRL_CICADA_RESP_DEV_AUTH_PUBKEY
    self._success_response[self.CMDCTRL_CICADA_CMD_REBOOT] = self.CMDCTRL_CICADA_RESP_SET_OK
    self._success_response[self.CMDCTRL_CICADA_CMD_GET_DEV_CERTIFICATE] = self.CMDCTRL_CICADA_RESP_DEV_CERTIFICATE

    self._payload_size[self.CMDCTRL_CICADA_RESP_SET_OK] = 0
    self._payload_size[self.CMDCTRL_CICADA_RESP_DEV_AUTH_PUBKEY] = 64
    self._payload_size[self.CMDCTRL_CICADA_RESP_DEV_CERTIFICATE] = 64

  def _set_function(self, data_id, data, program=0):
    cmd = 0

    if(data_id == "auth"):
      cmd = self.CMDCTRL_CICADA_CMD_SET_AUTH
    elif(data_id == "enc"):
      cmd = self.CMDCTRL_CICADA_CMD_SET_ENC
    elif(data_id == "serial"):
      cmd = self.CMDCTRL_CICADA_CMD_SET_SERIAL
    elif(data_id == "hwrev"):
      cmd = self.CMDCTRL_CICADA_CMD_SET_HW_REV
    elif(data_id == "protocol_ca"):
      cmd = self.CMDCTRL_CICADA_CMD_SET_PROTOCOL_CA
    elif(data_id == "target"):
      cmd = self.CMDCTRL_CICADA_CMD_SET_TARGET
    elif(data_id == "led_level"):
      cmd = self.CMDCTRL_CICADA_CMD_SET_LED_LEVEL
    else:
      print("Data ID not recognized")
      return None
    
    payload = b'\xA1\x25' # QCICada Cmd&Ctrl custom command magic number
    payload = payload + data + struct.pack("<B", program)
    checksum = self._calc_checksum8(payload)
    payload = payload + struct.pack("<B", checksum)
    return self.command(cmd, payload)
  
  def reboot(self):
    return self.command(self.CMDCTRL_CICADA_CMD_REBOOT, b'\xA1\x25')
  
  def _hwrev_str_to_int(self, hwrev):
    if(hwrev == "1.0"):
      return 0x0100
    elif(hwrev == "1.1"):
      return 0x0101
    else:
      print("HW revision should be 1.0 or 1.1")
      return None
  
  def set_auth(self, auth_key, passphrase="", program=0):
    key = self.extract_key_from_pem(auth_key, passphrase, 0)
    return self._set_function("auth", key, program)

  def set_enc(self, enc_key, passphrase="", program=0):
    key = self.extract_key_from_pem(enc_key, passphrase, 1)
    return self._set_function("enc", key, program)
  
  def set_serial(self, serial, program=0):
    return self._set_function("serial", struct.pack("<I",serial), program)
  
  def set_hwrev(self, hwrev, program=0):
    hwrev_int = self._hwrev_str_to_int(hwrev)

    if(hwrev_int is None):
      return None
    
    return self._set_function("hwrev", struct.pack("<H",hwrev_int), program)
  
  def set_device_certificate(self, ca_pem_file, passphrase="", program=0):

    # Read device serial and hw revision
    info = self.get_info()
    if(not info):
      print("Error reading info")
      return None
    
    # Encode the HW revision major and minor numbers in integers, the HW info string is QCICADA-QRNG-<maj>.<min>
    hwrev = info['hw_info'].decode("utf-8").replace("CICADA-QRNG-","")

    # Encode the serial number in an integer
    serial = int(info['serial'].decode("utf-8").replace("QC",""))

    #read device auth key
    device_auth_pubkey = self.get_dev_auth_pubkey()
    if(device_auth_pubkey is None):
      print("Error reading device Auth public key")
      return None
    time.sleep(0.05)
    
    # Compute device certificate and sign
    to_sign = struct.pack("<HHI", 0, self._hwrev_str_to_int(hwrev), serial)
    to_sign = to_sign + device_auth_pubkey
    
    # Load the private key from a PEM file
    with open(ca_pem_file, "rb") as key_file:
      private_key = self.serialization.load_pem_private_key(key_file.read(), password=passphrase.encode("utf-8"),
            backend=self.backends.default_backend())

    # Sign the data using ECDSA
    signature = private_key.sign(
        to_sign,
        self.ec.ECDSA(self.hashes.SHA256())  # Explicitly specify SHA-256
    )

    # Extract the individual r and s values
    r, s = self.utils.decode_dss_signature(signature)

    # Concatenate r and s into a 64-byte bytearray
    r_s_bytes = r.to_bytes(32, byteorder='big') + s.to_bytes(32, byteorder='big')
    return self._set_function("protocol_ca", r_s_bytes, program)
  
  def set_target(self, target, program=0):
    return self._set_function("target", struct.pack("<H",target), program)
  
  def set_led_level(self, led_level, program=0):
    return self._set_function("led_level", struct.pack("<f",led_level), program)
  
  def get_dev_auth_pubkey(self):
    if(self.command(self.CMDCTRL_CICADA_CMD_GET_DEV_AUTH_PUBKEY, None)):
      return self.resp_payload
    else:
      return None
    
  def get_dev_certificate(self):
    if(self.command(self.CMDCTRL_CICADA_CMD_GET_DEV_CERTIFICATE, None)):
      return self.resp_payload
    else:
      return None

  # Get the verified raw device public key, the authenticity of the device key is verified with the Certificate Authority public key
  # ca_pubkey_pem_file: path to the PEM file containing the Certificate Authority public key
  # If the verification is successful, return the device public key
  def get_dev_auth_key_verified(self, ca_pubkey_pem_file):
    # Read device serial and hw revision
    info = self.get_info()
    if(not info):
      print("Error reading info")
      return None
    
    # Encode the HW revision major and minor numbers in integers, the HW info string is QCICADA-QRNG-<maj>.<min>
    hw_rev_str = info['hw_info'].decode("utf-8").replace("CICADA-QRNG-","")
    hw_rev_components = hw_rev_str.split(".")
    hwrev_maj = int(hw_rev_components[0])
    hwrev_min = int(hw_rev_components[1])

    # Encode the serial number in an integer
    serial_int = int(info['serial'].decode("utf-8").replace("QC",""))

    # Read device public key
    device_auth_pubkey = self.get_dev_auth_pubkey()
    if(device_auth_pubkey is None):
      print("Error reading device Auth public key")
      return None
    
    # Read device certificate
    dev_cert = self.get_dev_certificate()

    # Extract CA public key from PEM file
    with open(ca_pubkey_pem_file, "rb") as pem_file:
      pem_data = pem_file.read()

    try:
      ca_public_key = self.serialization.load_pem_public_key(
              pem_data,
              backend=self.backends.default_backend()
      )
    except ValueError as e:
      print(f"Error loading PEM public key: {e}")
      return None
  
    # Compute the certificate information to verify
    to_verify = struct.pack("<HBBI", 0, hwrev_maj, hwrev_min, serial_int)
    to_verify = to_verify + device_auth_pubkey

    # Verify certificate signature
    sig_r = int.from_bytes(dev_cert[0:32],"big")
    sig_s = int.from_bytes(dev_cert[32:64],"big")
    encoded_signature = self.utils.encode_dss_signature(sig_r,sig_s)
  
    try:
      ca_public_key.verify(
          encoded_signature,
          to_verify,
          self.ec.ECDSA(self.hashes.SHA256())
      )
    except self.InvalidSignature:
      print("Device certificate signature is invalid!")
      return None
    
    # Return verified device public key
    return device_auth_pubkey
  
  def extract_key_from_pem(self, pem_file_path, passphrase, private):

    with open(pem_file_path, "rb") as pem_file:
      pem_data = pem_file.read()

    try:
      key = self.serialization.load_pem_private_key(
            pem_data,
            password=passphrase.encode("utf-8"),
            backend=self.backends.default_backend()
        )
      if not isinstance(key, self.ec.EllipticCurvePrivateKey) or not key.curve.name == 'secp256r1':
          raise ValueError("Not a NIST P-256 EC public key")
      
      if(private):
        return key.private_numbers().private_value.to_bytes(32, byteorder='big')
      else:
        public_numbers = key.public_key().public_numbers()
        return public_numbers.x.to_bytes(32, byteorder='big') + public_numbers.y.to_bytes(32, byteorder='big')
        
    except ValueError as e:
        raise ValueError(f"Error loading PEM key: {e}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description= 'QRNG Command Line low-level utility')
    parser.add_argument('-i','--interface', dest='interface',choices=['serial', 'udp', 'tcp', 'tcpudp'], default='serial',
                        help='Communication interface (default: serial')
    parser.add_argument('-d','--device', dest='device', default='/dev/ttyUSB0',
                        help='Device interface name')
    parser.add_argument('--get-dev-certificate', dest='certificate', action = "store_true",
                        help='Get current QRNG device certificate')

    args = parser.parse_args()
    cc = qrng_cmdctrl_qcicada(args.interface, args.device)

    if args.certificate:
        certificate = cc.get_dev_certificate()
    if certificate is not None:
        print("### CERTIFICATE:")
        print(certificate)
    else:
      print("Error reading certificate")
      sys.exit(1)

    sys.exit(0)
