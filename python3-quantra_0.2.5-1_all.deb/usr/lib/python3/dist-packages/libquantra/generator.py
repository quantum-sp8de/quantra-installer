from abc import ABC, abstractmethod
import random
import time
import logging
import numpy
import subprocess
from quantralib.cipher import xor_crypt_encode, generate_dynamic_key

log = logging.getLogger('quantra')

QUANTIS_ON_FAIL_RETRIES = 60
QUANTIS_BUFFER_SIZE = 4096

class RandomGenerator(ABC):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        self.chain = chain_obj
        self.account = pubkey_account
        self.key = None
        self.last_tcheckpoint = None
        self.upinterval = update_interval

    @abstractmethod
    def _generate(self):
        pass

    def check_time_passed(self):
        # first run
        if not self.last_tcheckpoint:
            return True
        tcurrent = time.time()
        if (tcurrent - self.last_tcheckpoint) >= self.upinterval:
            return False

        return True

    def reset_dynamic_keys(self):
        # re-reading is required because we can continue after stop
        old_key = self.chain.get_dynamic_encrypt_pubkey(self.account)
        if old_key:
            self.chain.set_dynamic_backup_pubkey(self.account, old_key)
        self.key = generate_dynamic_key()
        self.chain.set_dynamic_encrypt_pubkey(self.account, self.key)
        log.debug("Re-set dynamic dynpubkey in chain to value: %s" % self.key)

    def generate(self):
        encrypted = None
        value = self._generate()
        if not self.key or not self.check_time_passed():
            # set new dynpubkey for account and reload timer
            self.last_tcheckpoint = time.time()
            self.reset_dynamic_keys()
        else:
            self.key = self.chain.get_dynamic_encrypt_pubkey(self.account)
            log.debug("Using value of dynpubkey from the chain: %s" % self.key)

        encrypted = xor_crypt_encode(str(value), self.key)

        return encrypted

class RandomGeneratorQuantis(RandomGenerator):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)
        try:
            from .quantis import quantis_read, QuantisReadError
            self.quantis_read = quantis_read
            self.QuantisReadError = QuantisReadError
        except Exception as ex:
            log.error(ex)
            raise RuntimeError("QUANTIS hardware is not available") from None

        self.quantis_buffer = []

    def _generate(self):
        if len(self.quantis_buffer) == 0:
            # reading may block other clients while doing op, so keep attempts here
            for _ in range(QUANTIS_ON_FAIL_RETRIES):
                log.debug("Trying to read buffer from quantis device")
                try:
                    self.quantis_buffer = self.quantis_read(QUANTIS_BUFFER_SIZE)
                    break
                except self.QuantisReadError as ex:
                    log.warning("Quantis reading failed with reason: %s" % ex)
                    time.sleep(1)

        r = self.quantis_buffer.pop()
        r = (r << 8) + self.quantis_buffer.pop()

        return r

class RandomGeneratorUrandom(RandomGenerator):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)
        self.urandom = random.SystemRandom()

    def _generate(self):
        return self.urandom.randint(0, 65536)

class RandomGeneratorQuantisRemote(RandomGenerator):
    def __init__(self, chain_obj, pubkey_account, update_interval=10, **kwargs):
        RandomGenerator.__init__(self, chain_obj, pubkey_account, update_interval)

        try:
            self.ssh_user = kwargs["ssh_user"]
            self.ssh_host = kwargs["ssh_host"]
            self.ssh_pass = kwargs["ssh_pass"]
        except KeyError:
            raise RuntimeError("One of the ssh_user, ssh_host or ssh_pass hasn't been provided in config") from None

    def _generate(self):
        r = subprocess.run("sshpass -p {} ssh -o 'StrictHostKeyChecking no' {}@{} ssh_random".format(self.ssh_pass,
                                                                       self.ssh_user,
                                                                       self.ssh_host),
                                                                       shell=True,
                                                                       stdout=subprocess.PIPE)
        if r.returncode != 0:
            raise RuntimeError("Unable to get random from QUANTIS remotely. Please, check your ssh/sshpass, host and user creds")

        str_short = r.stdout.decode().strip()
        return int(str_short)

RandomGeneratorFactory = {
    "quantis": RandomGeneratorQuantis,
    "ssh_quantis": RandomGeneratorQuantisRemote,
    "system": RandomGeneratorUrandom,
}
