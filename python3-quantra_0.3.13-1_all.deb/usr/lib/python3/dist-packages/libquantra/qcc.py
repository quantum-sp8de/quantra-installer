#! /usr/bin/python3
# QRNG Cmd & Control protocol library and command line tool
#
# Copyright (c) Crypta Labs 2022
# Originated by davide@cryptalabs.com 17/02/2022
import socket
import argparse
import struct
import datetime
import os

verbose = False

def debug_print(str):
  if(verbose):
    print(str)

MAX_BLOCK_SIZE = 4096

class comm_serial :

  def __init__(self, device_name):
    import serial
    self._ser = serial.Serial(device_name, baudrate=1000000, inter_byte_timeout = 0.1, timeout = 1, write_timeout = 1)
    pass

  def flush(self):
    self._ser.flush()
    pass

  def set_timeout(self, timeout):
    self._ser.timeout = timeout
    pass

  def write(self, data):
    return self._ser.write(data)

  def read(self, length):
    return self._ser.read(length)
  
  def read_random(self, length):
    return self.read(length)

  def close(self):
    self._ser.close()
    pass


class comm_udp :
  """UDP communication interface"""
  UDP_PORT = 54936
  FLUSH_SIZE = 8000
  UDP_MAX_DGRAM_SIZE = 1500

  def __init__(self, device_name):
    debug_print(socket.gethostname())
    self._sock = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP
    #self._sock.bind(("0.0.0.0", self.UDP_PORT))
    self._device_name = device_name
    self.set_timeout(4)
    self._rx_buffer = bytearray()
    return

  def flush(self):
    self._sock.settimeout(0.000001)
    while True:
      try:
        data, addr = self._sock.recvfrom(self.FLUSH_SIZE)
        debug_print("flush:{}".format(len(data)))
      except socket.timeout:
        # We expect a timeout
        break
    self._sock.settimeout(self._timeout)
    self._rx_buffer = bytearray()
    pass

  def set_timeout(self, timeout):
    self._timeout = timeout
    self._sock.settimeout(self._timeout)
    pass

  def write(self, data):
    return self._sock.sendto(data, (self._device_name, self.UDP_PORT))

  def read(self, length):
    debug_print("Read")
    while(len(self._rx_buffer) < length):
      try:

        data, addr = self._sock.recvfrom(self.UDP_MAX_DGRAM_SIZE)
        self._rx_buffer.extend(data)
        #print(data)
      except socket.timeout:
        # A timeout can happen:
        #  - Empty Rx buffer
        #  - Return current data
        debug_print("timeout, rx buffer len:{}".format(len(self._rx_buffer)))
        ret_data = bytes(self._rx_buffer)
        self._rx_buffer = bytearray()
        return ret_data
    debug_print("rx buffer len: {}. requested length:{}".format(len(self._rx_buffer),length))
    ret_data = bytes(self._rx_buffer[:length])
    del self._rx_buffer[:length]

    return ret_data

  def read_random(self, length):
    return self.read(length)
  
  def close(self):
    pass

class comm_tcp :
  """TCP communication interface"""
  TCP_PORT = 54936
  FLUSH_SIZE = 8000
  TCP_MAX_SIZE = 1072

  def __init__(self, device_name):
    debug_print(socket.gethostbyname(device_name))

    self._sock = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_STREAM) #TCP
    self._device_name = socket.gethostbyname(device_name)
    self._reconnect()
    return

  def _reconnect(self):
    self._sock.connect((self._device_name, self.TCP_PORT))
    self.set_timeout(3)
    self._rx_buffer = bytearray()
    return

  def flush(self):
  #  self._sock.settimeout(0.000001)
  #  while True:
  #    try:
  #      data, addr = self._sock.recvfrom(self.FLUSH_SIZE)
  #      debug_print("flush:{}".format(len(data)))
  #    except socket.timeout:
  #      # We expect a timeout
  #      break
  #  self._sock.settimeout(self._timeout)
  #  self._rx_buffer = bytearray()
    pass

  def set_timeout(self, timeout):
    self._timeout = timeout
    self._sock.settimeout(self._timeout)
    pass

  def write(self, data):
    debug_print("Write")
    return self._sock.sendall(data)

  def read(self, length):
    debug_print("Read")
    while(len(self._rx_buffer) < length):
      try:
        if (length - len(self._rx_buffer) < self.TCP_MAX_SIZE):
          to_read = length - len(self._rx_buffer)
        else:
          to_read = self.TCP_MAX_SIZE
        data = self._sock.recv(to_read)
        if(len(data) == 0):
          ret_data = bytes(self._rx_buffer)
          self._rx_buffer = bytearray()
          return ret_data
        # TODO: check address
        self._rx_buffer.extend(data)
        #print(data)
      except socket.timeout:
        # A timeout can happen:
        #  - Empty Rx buffer
        #  - Return current data
        debug_print("timeout, rx buffer len:{}".format(len(self._rx_buffer)))
        ret_data = bytes(self._rx_buffer)
        self._rx_buffer = bytearray()
        return ret_data
    debug_print("rx buffer len: {}. requested length:{}".format(len(self._rx_buffer),length))
    ret_data = bytes(self._rx_buffer[:length])
    del self._rx_buffer[:length]

    return ret_data
  
  def read_random(self, length):
    return self.read(length)

  def close(self):
    self._sock.close()
    pass

class comm_tcp_udp(comm_tcp) :
  """TCP/UDP communication interface"""
  UDP_PORT = 54936
  UDP_MAX_DGRAM_SIZE = 65536

  def __init__(self, device_name):
    self._sock_udp = socket.socket(socket.AF_INET, # Internet
                    socket.SOCK_DGRAM) #UDP
    self._sock_udp.bind(("0.0.0.0", self.UDP_PORT))
    self._rx_random_buffer = bytearray()
    comm_tcp.__init__(self, device_name)
    # set kep alive for linux
    #self._sock.setsockopt(socket.SOL_SOCKET,
    #                socket.SO_KEEPALIVE, 1)
    #self._sock.setsockopt(socket.IPPROTO_TCP, 
    #                socket.TCP_KEEPINTVL, 1)
    #set keepalive for windows
    #self._sock.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 1000, 1000))
    return

  def flush(self):
    self._sock_udp.settimeout(0.000001)
    while True:
      try:
        data, addr = self._sock_udp.recvfrom(self.FLUSH_SIZE)
        debug_print("flush:{}".format(len(data)))
      except socket.timeout:
        # We expect a timeout
        break
    self._sock_udp.settimeout(self._timeout_udp)
    self._rx_random_buffer = bytearray()
    pass

  def set_timeout(self, timeout):
    comm_tcp.set_timeout(self, timeout)
    self._timeout_udp = timeout
    self._sock_udp.settimeout(self._timeout_udp)
    pass
  
  def read_random(self, length):
    debug_print("Read random")
    while(len(self._rx_random_buffer) < length):
      try:

        data, addr = self._sock_udp.recvfrom(self.UDP_MAX_DGRAM_SIZE)
        self._rx_random_buffer.extend(data)
        #print(data)
      except socket.timeout:
        # A timeout can happen:
        #  - Empty Rx buffer
        #  - Return current data
        debug_print("timeout, rx buffer len:{}".format(len(self._rx_random_buffer)))
        ret_data = bytes(self._rx_random_buffer)
        self._rx_random_buffer = bytearray()
        return ret_data
    debug_print("rx buffer len: {}. requested length:{}".format(len(self._rx_random_buffer),length))
    ret_data = bytes(self._rx_random_buffer[:length])
    del self._rx_random_buffer[:length]

    return ret_data

class qrng_cmdctrl:

  CMDCTRL_UPDATE_MAX_CHUNK = 1024

  CMDCTRL_UPDATE_STS_READY = 0
  CMDCTRL_UPDATE_STS_TRANSFER_IN_PROGRESS = 1
  CMDCTRL_UPDATE_STS_TRANSFER_COMPLETED = 2
  CMDCTRL_UPDATE_STS_ERR_NOT_INITIALIZED = 3
  CMDCTRL_UPDATE_STS_ERR_MEMORY = 4
  CMDCTRL_UPDATE_STS_ERR_VERIFICATION = 5
  CMDCTRL_UPDATE_STS_ERR_INVALID = 6

  CMDCTRL_CMD_GET_STATUS = b'\x01'
  CMDCTRL_CMD_START = b'\x04'
  CMDCTRL_CMD_STOP = b'\x05'
  CMDCTRL_CMD_GET_CONFIG = b'\x07'
  CMDCTRL_CMD_SET_CONFIG = b'\x08'
  CMDCTRL_CMD_GET_STATISTICS = b'\x09'
  CMDCTRL_CMD_RESET = b'\x0A'
  CMDCTRL_CMD_INFO = b'\x0B'
  CMDCTRL_CMD_HASH_TEST_INIT = b'\x20'
  CMDCTRL_CMD_HASH_TEST_ACCUMULATE = b'\x22'
  CMDCTRL_CMD_HASH_TEST_DIGEST = b'\x23'
  CMDCTRL_CMD_ENABLE_INSTANCE = b'\x30'
  CMDCTRL_CMD_UPDATE_INIT = b'\x40'
  CMDCTRL_CMD_UPDATE_CHUNK = b'\x41'
  CMDCTRL_CMD_SIGNED_READ = b'\x51'

  CMDCTRL_RESP_ACK = b'\x11'
  CMDCTRL_RESP_NACK = b'\x12'
  CMDCTRL_RESP_CONFIG = b'\x17'
  CMDCTRL_RESP_STATISTICS = b'\x19'
  CMDCTRL_RESP_INFO = b'\x1B'
  CMDCTRL_RESP_HASH_TEST_ACK = b'\x21'
  CMDCTRL_RESP_HASH_TEST_DIGEST = b'\x24'
  CMDCTRL_RESP_UPDATE = b'\x43'
  CMDCTRL_RESP_SIGNED_READ = b'\x52'

  _success_response = {
    CMDCTRL_CMD_GET_STATUS : CMDCTRL_RESP_ACK,
    CMDCTRL_CMD_START : CMDCTRL_RESP_ACK,
    CMDCTRL_CMD_STOP : CMDCTRL_RESP_ACK,
    CMDCTRL_CMD_GET_CONFIG : CMDCTRL_RESP_CONFIG,
    CMDCTRL_CMD_SET_CONFIG : CMDCTRL_RESP_ACK,
    CMDCTRL_CMD_GET_STATISTICS : CMDCTRL_RESP_STATISTICS,
    CMDCTRL_CMD_RESET : CMDCTRL_RESP_ACK,
    CMDCTRL_CMD_INFO : CMDCTRL_RESP_INFO,
    CMDCTRL_CMD_HASH_TEST_INIT : CMDCTRL_RESP_HASH_TEST_ACK,
    CMDCTRL_CMD_HASH_TEST_ACCUMULATE : CMDCTRL_RESP_HASH_TEST_ACK,
    CMDCTRL_CMD_HASH_TEST_DIGEST : CMDCTRL_RESP_HASH_TEST_DIGEST,
    CMDCTRL_CMD_ENABLE_INSTANCE : CMDCTRL_RESP_ACK,
    CMDCTRL_CMD_UPDATE_INIT : CMDCTRL_RESP_UPDATE,
    CMDCTRL_CMD_UPDATE_CHUNK : CMDCTRL_RESP_UPDATE,
    CMDCTRL_CMD_SIGNED_READ : CMDCTRL_RESP_SIGNED_READ
  }

  _payload_size = {
    CMDCTRL_RESP_ACK : 5,
    CMDCTRL_RESP_NACK : 0,
    CMDCTRL_RESP_CONFIG : 12,
    CMDCTRL_RESP_STATISTICS : 30,
    CMDCTRL_RESP_INFO : 56,
    CMDCTRL_RESP_HASH_TEST_ACK : 0,
    CMDCTRL_RESP_HASH_TEST_DIGEST : 32,
    CMDCTRL_RESP_UPDATE : 5,
    CMDCTRL_RESP_SIGNED_READ : 0
  }

  def __init__(self, interface, device_name):

    if(interface == "serial"):
      self._comm = comm_serial(device_name)
    elif(interface == "udp"):
      self._comm = comm_udp(device_name)
    elif(interface == "tcp"):
      self._comm = comm_tcp(device_name)
    elif(interface == "tcpudp"):
      self._comm = comm_tcp_udp(device_name)
    else:
      raise IOError("Unknown interface {}, use only 'serial', 'udp', 'tcp' or 'tcpudp'".format(interface))

    self.resp_payload = b'0'

  def start_continuous(self):
    payload = struct.pack("<BH", 0x00, 0x00)
    return self.command(self.CMDCTRL_CMD_START, payload)

  def start_one_shot(self, length):
    payload = struct.pack("<BH", 0x01, (int)(length))
    if(self.command(self.CMDCTRL_CMD_START, payload)):
      self._comm.set_timeout(0.1 + 0.0001*length)
      qrnd = self._comm.read_random(length)
      if(len(qrnd) == length):
        return qrnd
      else:
        debug_print("QRNG length: {}".format(len(qrnd)))
        return None
    else:
     return None
  
  def read_continuos(self, length):
    self._comm.set_timeout(0.1 + 0.0001*length)
    qrnd = self._comm.read_random(length)
    if(len(qrnd) == length):
      return qrnd
    else:
      debug_print("QRNG length: {}".format(len(qrnd)))
      return None
    
  def read_signed(self, length):
    payload = struct.pack("<H", (int)(length))
    if(self.command(self.CMDCTRL_CMD_SIGNED_READ, payload)):
      self._comm.set_timeout(0.1 + 0.0001*length)
      qrnd = self._comm.read_random(length)
      #print(len(qrnd))
      signature = self._comm.read(64)
      #print(len(signature))
      if(len(qrnd) == length and len(signature) == 64):
        return {'qrnd' : qrnd, 
              'signature' : signature}
      else:
        return None
    else:
     return None
    
  def stop(self):
    return self.command(self.CMDCTRL_CMD_STOP)
  
  def reset(self):
    return self.command(self.CMDCTRL_CMD_RESET)

  def get_status(self):
    if(self.command(self.CMDCTRL_CMD_GET_STATUS, None)):
      fields = struct.unpack("<BI", self.resp_payload)
      return {'started' : (fields[0]) & 1, 
              'startup_test_in_progress' : (fields[0]>>1) & 1,
              'voltage_low' : (fields[0]>>2) & 1, 
              'voltage_high' : (fields[0]>>3) & 1, #
              'voltage_undefined' : (fields[0]>>4) & 1,
              'bitcount' : (fields[0]>>5) & 1, 
              'repetition_count' : (fields[0]>>6) & 1, 
              'adaptive_proportion' : (fields[0]>>7) & 1, 
              'ready_bytes' : fields[1] }
    else:
     return None

  def get_config(self):
    if(self.command(self.CMDCTRL_CMD_GET_CONFIG, None)):
      fields = struct.unpack("<BfBBBHH", self.resp_payload)
      return {'postprocess' : fields[0],
              'inital_level' : fields[1], 
              'startup_test' : (fields[2]) & 1,
              'auto_calibration' : (fields[2] >> 1) & 1, 
              'repetition_count' : (fields[2] >> 2) & 1,
              'adaptive_proportion' : (fields[2] >> 3) & 1,
              'bit_count' : (fields[2] >> 4) & 1,
              'generate_on_error' : (fields[2] >> 5) & 1,
              'n_lsbits' : fields[3], 
              'hash_input_size' : fields[4], 
              'block_size' : fields[5],
              'autocalibration_target' : fields[6]}
    else:
      return None

  def get_statistics(self):
    if(self.command(self.CMDCTRL_CMD_GET_STATISTICS, None)):
      fields = struct.unpack("<QIIIIHf", self.resp_payload)
      return {'generated_bytes' : fields[0],
              'repetition_count_failures' : fields[1], 
              'adaptive_proportion_failures' : fields[2], 
              'bitcount_failures' : fields[3],
              'speed' : fields[4], 
              'sensif_average' : fields[5], 
              'ledctrl_level' : fields[6]}
    else:
      return None

  def set_config(self,
                  postprocess,
                  inital_level,
                  startup_test,
                  auto_calibration,
                  repetition_count,
                  adaptive_proportion,
                  bit_count,
                  generate_on_error,
                  n_lsbits,
                  hash_input_size,
                  block_size,
                  autocalibration_target):

    byte_flags = (startup_test) | \
                  (auto_calibration << 1) | \
                  (repetition_count << 2) | \
                  (adaptive_proportion << 3) | \
                  (bit_count << 4) | \
                  (generate_on_error << 5)
    
    print("{:02X}\n".format(byte_flags))

    payload = struct.pack("<BfBBBHH",postprocess, inital_level, byte_flags, n_lsbits, hash_input_size, block_size, autocalibration_target)
    return self.command(self.CMDCTRL_CMD_SET_CONFIG, payload)

  def get_info(self):
    if(self.command(self.CMDCTRL_CMD_INFO, None)):
      fields = struct.unpack("<II24s24s", self.resp_payload)
      return {'core_version' : fields[0], 
              'sw_version' : fields[1],
              'serial' : fields[2][:fields[2].index(0)], 
              'hw_info' : fields[3][:fields[3].index(0)]}
    else:
     return None
    
  def hash_test_init(self):
    return self.command(self.CMDCTRL_CMD_HASH_TEST_INIT, None)
  
  def hash_test_accumulate(self, data):
    debug_print("Accumulate , data len = {}".format(len(data)))
    if(len(data) > 1024):
      return None
      
    payload = struct.pack("<H", (int)(len(data)))
    payload = payload + data

    if(len(data)<1024):
      payload = payload + bytearray(1024-len(data))
    debug_print("Accumulate , payload len = {}".format(len(payload)))
    return self.command(self.CMDCTRL_CMD_HASH_TEST_ACCUMULATE, payload)

  def hash_test_digest(self):
    if(self.command(self.CMDCTRL_CMD_HASH_TEST_DIGEST, None)):
      return self.resp_payload
    else:
      return None
    
  def enable_instance(self, instance, enable):
    payload = struct.pack("<BB", instance, enable)
    return self.command(self.CMDCTRL_CMD_ENABLE_INSTANCE, payload)
  
  def update_init(self, image_size):
    payload = struct.pack("<L", image_size)
    if(self.command(self.CMDCTRL_CMD_UPDATE_INIT, payload)):
      fields = struct.unpack("<BL", self.resp_payload)
      return {'update_status' : fields[0],
              'remaining' : fields[1]}
    else:
      return None
    
  def _calc_checksum8(self, data):
    checksum = 0
    for byte in data:
        checksum += byte
    checksum &= 0xFF  # Constrain to 8 bits
    checksum = ~checksum & 0xFF  # Apply 1's complement
    return checksum
  
  def update_chunk(self, data):
    if(len(data) > self.CMDCTRL_UPDATE_MAX_CHUNK):
      print("Chunk exceed maximum size")
      return None
    
    payload = struct.pack("<H", (int)(len(data)))

    #add padding
    if(len(data)<self.CMDCTRL_UPDATE_MAX_CHUNK):
      data = data + bytearray(self.CMDCTRL_UPDATE_MAX_CHUNK-len(data))

    checksum = self._calc_checksum8(data)
    payload = payload + data + struct.pack("<B", checksum)
    
    if(self.command(self.CMDCTRL_CMD_UPDATE_CHUNK, payload)):
      fields = struct.unpack("<BL", self.resp_payload)
      return {'update_status' : fields[0],
              'remaining' : fields[1]}
    else:
      return None

  def command(self, cmd_code, payload=None):
    self._comm.flush()
    if(cmd_code not in self._success_response.keys()):
      raise ValueError("Command code 0x{02X} not valid".format(cmd_code))

    to_send = cmd_code; 
    if(payload != None):
      to_send += payload
    
    try:
      debug_print("to_send len:{}".format(len(to_send)) )
      self._comm.write(to_send)
    except IOError as ex:
      print("Exception:" + str(ex))
      return False

    # For the stop command we need to empty the Rx buffer and check that the last byte is a ACK
    if(cmd_code == self.CMDCTRL_CMD_STOP):
      try:
        self._comm.set_timeout(0.1) # 100 millisecond
        retry = 2
        while (retry > 0):
          resp = self._comm.read(MAX_BLOCK_SIZE*2 + self._payload_size[self.CMDCTRL_RESP_ACK] + 1 )
          debug_print("Resp length: {}".format(len(resp)))
          if(len(resp) == 1 and resp == self.CMDCTRL_RESP_NACK):
            debug_print("NACK received")
            return False
          if(len(resp) < self._payload_size[self.CMDCTRL_RESP_ACK] + 1 ):
            debug_print("Stop command, no response")
            return False
          if( resp[len(resp) - 1 - self._payload_size[self.CMDCTRL_RESP_ACK]] == self.CMDCTRL_RESP_ACK[0]):
            return True
          else:
            debug_print("Stop command,received {} bytes, last received byte: {}".format(len(resp), resp[len(resp) - 1 - self._payload_size[self.CMDCTRL_RESP_ACK]]))
            if retry == 0:
              return False
          retry = retry - 1
      except IOError as ex:
        debug_print("Exception: " + str(ex))
        return False

    try:
      self._comm.set_timeout(3)
      resp = self._comm.read(1)
      debug_print("response length: {}".format(len(resp)))
      if(len(resp) == 0):
        return False
    except Exception as ex:
      debug_print("Exception:" + str(ex))
      return False

    if(resp == self._success_response[cmd_code]):
      expected_payload = self._payload_size[self._success_response[cmd_code]]
      debug_print(expected_payload)
      if(expected_payload > 0):
        try:
          self._comm.set_timeout(0.001*expected_payload)
          self.resp_payload = self._comm.read(expected_payload)
          debug_print("Payload length: {}".format(len(self.resp_payload)))
          if(len(self.resp_payload) != expected_payload):
            return False
        except IOError as ex:
          debug_print("Exception:" + str(ex))
          return False

      return True
    elif (resp == self.CMDCTRL_RESP_NACK):
      return False
    else:
      raise RuntimeError("Unexpected byte received: 0x{}".format(resp.hex()))
    
  def get_resp_payload(self):
    return self.resp_payload
  
  def close_comm(self):
    self._comm.close()

# Command line tool
if __name__ == "__main__":

  def postprocess_name_to_code(name):
    if(name == 'RAW_SAMPLE'):
      return 2
    elif (name == 'RAW_NOISE'):
      return 1
    elif (name == 'SHA256'):
      return 0
    else:
      return 0xff
      
  parser = argparse.ArgumentParser(description= 'QRNG Command and Control protocol host utility')
  parser.add_argument('-i','--interface', dest='interface',choices=['serial', 'udp', 'tcp', 'tcpudp'], default='serial',
                      help='Communication interface (default: serial') 
  parser.add_argument('-d','--device', dest='device', default='/dev/ttyACM0',
                      help='Device interface name or IP (default: /dev/ttyACM0)')
  parser.add_argument('-s','--get-status', dest='status', action = "store_true",
                      help='Get current QRNG configuration')
  parser.add_argument('-g','--get-config', dest='get_config', action = "store_true",
                      help='Get current QRNG configuration')
  parser.add_argument('-t','--get-statistics', dest='get_stats', action = "store_true",
                      help='Get QRNG statistics')
  parser.add_argument('-r','--read', dest='read_size', type=int, default=0,
                      help='One shot read')
  parser.add_argument('-R','--signed-read', dest='signed_read_size', type=int, default=0,
                      help='Signed read')
  parser.add_argument('-o','--output-file', dest='output_file', type=str,
                      help='Output file (used with -r, --read)')
  parser.add_argument('-a','--append', dest='append', action = "store_true",
                      help='Append to output file (used with -o, --output-file)')
  parser.add_argument('--start', action = "store_true",
                      help='Start continuous mode, if -r is used: read in continuos mode')
  parser.add_argument('--read-block-size', dest='read_block_size', type=int, default=1024,
                      help='Read block size, how many bytes read for every cycle (continuos mode only)')
  parser.add_argument('--stop', action = "store_true",
                      help='Stop continuous mode')
  parser.add_argument('--reset', action = "store_true",
                      help='Reset error statistics and repeat start-up test')
  parser.add_argument('--info', action = "store_true",
                      help='Get device information')
  parser.add_argument('-e','--enable', dest='instance_en', type=int, default=-1,
                      help='Enable instance, for multi QOM QRNG ')
  parser.add_argument('-n','--disable', dest='instance_dis', type=int, default=-1,
                      help='Disable instance, for multi QOM QRNG ')

  # QRNG configuration parameters
  parser.add_argument('-c','--set-config', dest='set_config', action = "store_true",
                      help='Configure post-processing, see following parameters') 
  parser.add_argument('--postprocess', dest='postprocess', choices=['RAW_SAMPLE','RAW_NOISE','SHA256'], default= 'SHA256',
                      help='Type of conditioning (to be used with --set-config option)')
  parser.add_argument('--hash-input-size',dest='hash_input_size', type=int, default= 64,
                      help='Number of bytes used as input for the HASH SHA256 conditioning (to be used with --set-config option)')
  parser.add_argument('--block-size',dest='block_size', type=int, default= 256,
                      help='Block size, the random  number are generated in blocks (to be used with --set-config option)')
  parser.add_argument('--lsbits',dest='lsbits', type=int, choices=[1,2,3,4,5,6,7,8], default= 8,
                      help='Number of LSbits of the ADC to be used (to be used with --set-config option)')
  parser.add_argument('--auto-calibration', dest='auto_calibration', action = "store_true",
                      help='Enable auto calibration (to be used with --set-config option)')
  parser.add_argument('--target-value', dest='target_value', type=int, default=1279,
                      help='Target value for the auto-calibration (to be used with --target-value option), default value is 1279.')
  parser.add_argument('--startup-test',dest='startup_test', action = "store_true",
                      help='Enable startup test (to be used with --set-config option)')
  parser.add_argument('--repetition-count',dest='repetition_count', action = "store_true",
                      help='Enable repetition count test (to be used with --set-config option)')
  parser.add_argument('--adaptive-proportion',dest='adaptive_proportion', action = "store_true",
                      help='Enable adaptive proportion test (to be used with --set-config option)')
  parser.add_argument('--bit-count',dest='bit_count', action = "store_true",
                      help='Enable bit count test (to be used with --set-config option)')
  parser.add_argument('--generate-on-error',dest='generate_on_error', action = "store_true",
                      help='Geerate random data and fill the buffer even in case of health test failure (to be used with --set-config option)')
  parser.add_argument('--initial-ledctrl', dest='initial_ledctrl', type=float, default = 70,
                      help='Initial LED control PWM duty cycle %% (0 - 100) (to be used with --set-config option)') 
  
  parser.add_argument('--hash-test', dest='hash_in_file', type=str,
                      help='Hash test, input file')
  
  parser.add_argument('--update', dest='update_file', type=str,
                      help='FW update, image file')
  
  parser.add_argument('-v','--verbose', action = "store_true",
                      help='Print debug information')

  args = parser.parse_args()

  if(args.verbose):
    verbose = True

  cc = qrng_cmdctrl(args.interface, args.device) 

  if(args.status):
    status = cc.get_status()
    if(status is not None):
      print("### STATUS:")
      print(" started: {}".format(status['started']) )
      print(" startup_test_in_progress: {}".format(status['startup_test_in_progress']) )
      print(" voltage_low: {}".format(status['voltage_low']) )
      print(" voltage_high: {}".format(status['voltage_high']) )
      print(" voltage_undefined: {}".format(status['voltage_undefined']) )
      print(" bitcount: {}".format(status['bitcount']) )
      print(" repetition_count: {}".format(status['repetition_count']) )
      print(" adaptive_proportion: {}".format(status['adaptive_proportion']) )
      print(" Ready bytes: {}".format(status['ready_bytes']) )
    else:
      print("Error reading status")
      quit()

  if(args.get_config):
    config = cc.get_config()
    if(config is not None):
      print("### CONFIGURATION:")
      print(" postprocess: {}".format(config['postprocess']) )
      print(" initial_level: {}".format(config['inital_level']) )
      print(" startup_test: {}".format(config['startup_test']) )
      print(" auto_calibration: {}".format(config['auto_calibration']) )
      print(" repetition_count: {}".format(config['repetition_count']) )
      print(" adaptive_proportion: {}".format(config['adaptive_proportion']) )
      print(" bit_count: {}".format(config['bit_count']) )
      print(" generate_on_error: {}".format(config['generate_on_error']) )
      print(" n_lsbits: {}".format(config['n_lsbits']) )
      print(" hash_input_size: {}".format(config['hash_input_size']) )
      print(" block_size: {}".format(config['block_size']) )
      print(" autocalibration_target: {}".format(config['autocalibration_target']) )
    else:
      print("Error reading configuration")
      quit()

  if(args.get_stats):
    stats = cc.get_statistics()
    if(stats is not None):
      print("### STATISTICS:")
      print(" generated bytes: {}".format(stats['generated_bytes']) )
      print(" repetition count failures: {}".format(stats['repetition_count_failures']) )
      print(" adaptive proportion failures: {}".format(stats['adaptive_proportion_failures']) )
      print(" bitcount failures: {}".format(stats['bitcount_failures']) )
      print(" LED level: {}%".format(stats['ledctrl_level']) )
      print(" ADC average: {}".format(stats['sensif_average']) )
    else:
      print("Error reading statistics")
      quit()

  if(args.set_config):
    ret = cc.set_config(postprocess_name_to_code(args.postprocess), 
                      args.initial_ledctrl,
                      1 if args.startup_test else 0,
                      1 if args.auto_calibration else 0,
                      1 if args.repetition_count else 0,
                      1 if args.adaptive_proportion else 0, 
                      1 if args.bit_count else 0,
                      1 if args.generate_on_error else 0,
                      args.lsbits,
                      args.hash_input_size,
                      args.block_size,
                      args.target_value)
    if(ret):
      print("### SET CONFIGURATION DONE")
      print(" postprocess: {}".format(args.postprocess) )
      print(" inital_level: {}".format(args.initial_ledctrl) )
      print(" startup_test: {}".format(args.startup_test) )
      print(" auto_calibration: {}".format(args.auto_calibration) )
      print(" repetition_count: {}".format(args.repetition_count) )
      print(" adaptive_proportion: {}".format(args.adaptive_proportion) )
      print(" bit_count: {}".format(args.bit_count) )
      print(" generate_on_error: {}".format(args.generate_on_error) )
      print(" n_lsbits: {}".format(args.lsbits) )
      print(" hash_input_size: {}".format(args.hash_input_size) )
      print(" block_size: {}".format(args.block_size) )
      print(" autocalibration_target: {}".format(args.target_value) )

    else:
      print("Error during QRNG configuration")
      quit()

  if(args.info):
    info = cc.get_info()
    if(info is not None):
      print("### GET INFO DONE")
      print(" Core version: {}.{}".format(info['core_version'] >> 16, info['core_version'] & 0xffff) )
      print(" SW version: {}.{}".format(info['sw_version'] >> 16, info['sw_version'] & 0xffff) )
      print(" Serial: {}".format(info['serial'].decode("utf-8")))
      print(" HW info: {}".format(info['hw_info'].decode("utf-8")))
    else:
      print("Error reading info")
      quit()

  if(args.instance_en != -1):
    if(cc.enable_instance(args.instance_en, 1)):
      print("Instance {} enabled".format(args.instance_en))
    else:
      print("Enable error!")

  if(args.instance_dis != -1):
    if(cc.enable_instance(args.instance_dis, 0)):
      print("Instance {} disabled".format(args.instance_dis))
    else:
      print("Disable error!")

  if(args.reset):
    if(cc.reset() is not None):
      print("Reset done!")
    else:
      print("Reset error!")
      quit()

  if(args.start):
    result = cc.start_continuous()
    if(result):
      print("Continuous mode started!")
      if(args.read_size):
        binary_file = None
        if(args.output_file):
            binary_file = open(args.output_file, "ab" if (args.append) else "wb")
        total_read = 0
        a = datetime.datetime.now()
        while(total_read < args.read_size):
          to_read = args.read_block_size if (args.read_size - total_read > args.read_block_size) else (args.read_size - total_read) 
          reading = cc.read_continuos(to_read)
          if(reading != None):
            debug_print("Continuos read of {} bytes success! {:02X}..{:02X}".format(to_read, reading[0], reading[-1]))
            total_read += to_read
            if(binary_file):
                binary_file.write(reading)
          else:
            debug_print("Continuos read of {} bytes error!".format(to_read))
            break
        b = datetime.datetime.now()
        c = b - a
        if(c.total_seconds() == 0):
          c = datetime.timedelta(milliseconds=1)  
        print(" Speed: {:12d} bit/s".format((int)((1/c.total_seconds())*(total_read)*8)))
        if(binary_file):
          binary_file.close()
    else:
      print("Error starting continuos mode!")
  elif(args.read_size):
    a = datetime.datetime.now()
    reading = cc.start_one_shot(args.read_size)
    if(reading != None):
      print("One shot read success")
      if(args.output_file):
        with open(args.output_file, "ab" if (args.append) else "wb") as binary_file:
          # Write bytes to file
          binary_file.write(reading)
      b = datetime.datetime.now()
      c = b - a
      if(c.total_seconds() == 0):
        c = datetime.timedelta(milliseconds=1)  
      print(" Speed: {:12d} bit/s".format((int)((1/c.total_seconds())*(args.read_size)*8)))
      debug_print("data:");
      debug_print(reading.hex())
    else:
      print("Error one shot reading")
  elif(args.signed_read_size):
    a = datetime.datetime.now()
    reading = cc.read_signed(args.signed_read_size)
    if(reading != None):
      print("Signed read success")
      
      if(args.output_file):
        with open(args.output_file, "ab" if (args.append) else "wb") as binary_file:
          # Write bytes to file
          binary_file.write(reading['qrnd'])
      b = datetime.datetime.now()
      c = b - a
      if(c.total_seconds() == 0):
        c = datetime.timedelta(milliseconds=1)  
      print(" Speed: {:12d} bit/s".format((int)((1/c.total_seconds())*(args.read_size)*8)))
      debug_print("data:");
      debug_print(reading['qrnd'].hex())
      debug_print("Signature: " + reading['signature'].hex())

  if(args.stop):
    if(cc.stop()):
      print("Continuous mode Stopped!")
    else:
      print("Stop error!")

  if(args.hash_in_file):
    # call hash_digest to terminate a calculation if previously started
    cc.hash_test_digest()
    if(cc.hash_test_init()):
      print("Hash test initialized!")
    else:
      print("hash test init error!")
      quit()

    with open(args.hash_in_file, "rb") as binary_file:
      chunk = binary_file.read(1024)
      if(cc.hash_test_accumulate(chunk) == False):
        print("hash test accumulate error!")
        quit()

    digest = cc.hash_test_digest()
    if(digest):
      print(digest)
    else:
      print("hash test digest error!")
      quit()

  if(args.update_file):
    image_size = os.path.getsize(args.update_file)
    debug_print("FW image file {}, size={}".format(args.update_file, image_size))
    update_resp = cc.update_init(image_size)
    if(update_resp == None):
      print("Error initializing update!")
      quit()

    if(update_resp['update_status'] != cc.CMDCTRL_UPDATE_STS_READY):
      print("The update cannot start, update status={}".format(update_resp['update_status']))
      quit()

    with open(args.update_file, "rb") as image_file:
      while True:
        chunk = image_file.read(cc.CMDCTRL_UPDATE_MAX_CHUNK)
        #try each chunk at least 3 times, sometims there are errror on the serial communication interface (e.g. Clicker board)
        for i in range(1,4):
          update_resp = cc.update_chunk(chunk)
          if(update_resp == None):
            debug_print("Error update chunk, retry")
            continue
          else:
            break

        if(update_resp == None):
          print("Error update chunk")
          quit()

        if(update_resp['update_status'] == cc.CMDCTRL_UPDATE_STS_TRANSFER_IN_PROGRESS):
          debug_print("Sent {} bytes, remaining {} bytes, continue...".format(len(chunk), update_resp['remaining']))
          continue
        
        if(update_resp['update_status'] == cc.CMDCTRL_UPDATE_STS_TRANSFER_COMPLETED):
          print("Transfer completed, the new firmware is updating!")
          break
        
        print("Error during Update, udpate status={}".format(update_resp['update_status']))
        quit()

  quit()


